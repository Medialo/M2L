package fr.koala.m2l;

public class UserPreferences {


}
